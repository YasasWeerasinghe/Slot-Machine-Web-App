package controllers;

import play.mvc.*;

public class SlotAppController extends Controller {
    public Result index(){
        return ok(views.html.GUI.render());
    }

    public Result statistics(){
        return ok(views.html.Statistics.render());
    }
}
