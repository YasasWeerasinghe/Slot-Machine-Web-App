document.getElementById("btnSave").addEventListener("click",(e:Event) => this.Save());  // save button action listener
document.getElementById("btnClose").addEventListener("click",(e:Event) => this.Close());  // close button action listener


var sessionSorageValues;
sessionSorageValues=sessionStorage.getItem('listOfValues');
var stacValues = JSON.parse(sessionSorageValues);

//Set the JSON values
document.getElementById("status2").innerHTML="Total Credits: "+stacValues['Total Credits']+"  Total bet: "+stacValues['Total bets']+ "$"+ "    Total Play: " + stacValues['Total Play']
    + "     Total Wins: " + stacValues['Total Wins'] + "   Total Loss:" + stacValues['Total Loss'];


var drawPieChart = function(info, colors) {
    var canvas = <HTMLCanvasElement>document.getElementById('pieChart');
    var pieDetails = canvas.getContext('2d');
    var x_intercept = canvas.width / 2;
    var y_intercept = canvas.height / 2;
    var y_intercept = canvas.height / 2;
    var y_intercept = canvas.height / 2;
    var color,
        startAngle,
        endAngle,
        total = getTotal(info);

    for(var i=0; i<info.length; i++) {
        color = colors[i];
        startAngle = calculationStart(info, i, total);
        endAngle = calculationEnd(info, i, total);

        pieDetails.beginPath();
        pieDetails.fillStyle = color;
        pieDetails.moveTo(x_intercept, y_intercept);
        pieDetails.arc(x_intercept, y_intercept, y_intercept-100, startAngle, endAngle);
        pieDetails.fill();
        pieDetails.rect(canvas.width - 200, y_intercept - i * 30, 12, 12);
        pieDetails.fill();
        pieDetails.font = "13px sans-serif";
        pieDetails.fillText(info[i].label + " - " + info[i].value + " (" + calculatePercentage(info[i].value, total) + "%)", canvas.width - 200 + 20, y_intercept - i * 30 + 10);
    }
};

var calculatePercentage = function(value, total) {

    return (value / total * 100).toFixed(2);
};

var getTotal = function(info) {
    var sum = 0;
    for(var i=0; i<info.length; i++) {
        sum += info[i].value;
    }

    return sum;
};

var calculationStart = function(info, index, total) {
    if(index === 0) {
        return 0;
    }

    return calculationEnd(info, index-1, total);
};

var calculationEndAngle = function(info, index, total) {
    var angle = info[index].value / total * 360;
    var inc = ( index === 0 ) ? 0 : calculationEndAngle(info, index-1, total);

    return ( angle + inc );
};

var calculationEnd = function(info, index, total) {

    return Radians(calculationEndAngle(info, index, total));
};

var Radians = function(angle) {
    return angle * Math.PI / 180
}

var info = [ // show values in the pia chart
    { label: 'Total Loss', value: stacValues['Total Loss']},
    { label: 'Total Wins', value: stacValues['Total Wins']},

];
var colors = [ '#39CCCC', '#3D9970', '#001F3F', '#85144B' ];

drawPieChart(info, colors);

function Save(){
    alert("Data Saved") // save button alert
}

function Close(){ // window close function
    window.close();
}