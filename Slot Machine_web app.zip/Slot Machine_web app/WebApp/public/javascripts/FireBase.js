var save=document.getElementById("btnSave");

// Initialize Firebase
var config = {
    apiKey: "AIzaSyAjFzRIL15gCkEg-jgR65Qlqt2Fn6jdXeo",
    authDomain: "cw2-web-application.firebaseapp.com",
    databaseURL: "https://cw2-web-application.firebaseio.com",
    projectId: "cw2-web-application",
    storageBucket: "",
    messagingSenderId: "200241117680"
};
firebase.initializeApp(config);

save.onclick=function (ev) {
   var ref=firebase.database().ref();
   ref.set({TotalCredits: stacValues['Total Credits'],
       TotalPlay: stacValues['Total Play'],
        TotalBet: stacValues['Total bets'],
       TotalWins:  stacValues['Total Wins'] ,
    TotalLoss:stacValues['Total Loss']});
    }

