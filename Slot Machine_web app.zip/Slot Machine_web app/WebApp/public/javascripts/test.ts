
//variable initialize and declaration
var coinValue=10;
var betValue=0;
var noOfWins=0;
var noOfLoss=0;
var noOfPlay=0;
var totalBet=0;
var totalCretitValues=10;
var List:Array<Symbol>;
var reel1,reel2,reel3;

var spin1 : boolean;
var spin2 : boolean;
var spin3 : boolean;

spin1 = true;
spin2 = true;
spin3 = true;

var score1 : number;
var score2 : number;
var score3 : number;


//AddCoin button EventListener
document.getElementById("btnAdd").addEventListener("click",(e:Event) => this.addCoin()); // addCoin button action listener
(<HTMLInputElement>document.getElementById("txtAdd")).value;
//BetOne button EventListener
document.getElementById("btnBetOne").addEventListener("click",(e:Event) => this.BetOne()); // betOne button action listener
(<HTMLInputElement>document.getElementById("txtBet")).value;
//BetMax button EventListener
document.getElementById("btnBetMax").addEventListener("click",(e:Event) => this.BetMax()); // betMax button action listener
(<HTMLInputElement>document.getElementById("txtBet")).value;
//Reset button EventListener
document.getElementById("btnReset").addEventListener("click",(e:Event) => this.Reset());  // reset button action listener
//Spin button EventListener
document.getElementById("btnSpin").addEventListener("click",(e:Event) => this.Spin());  // spin button action listener
//Statistics button EventListener
document.getElementById("btnStatistics").addEventListener("click",(e:Event) => this.Statistics());  // statistics button action listener
//reel images EventListenersss
document.getElementById("reel1").addEventListener("click",(e:Event)=> this.stopReel1()); // reel1 image action listener
document.getElementById("reel2").addEventListener("click",(e:Event)=> this.stopReel2()); // reel2 image action listener
document.getElementById("reel3").addEventListener("click",(e:Event)=> this.stopReel3()); // reel3 image action listener


// image class.. set the image path and set values to the images
class Images{

    constructor(){

        var redseven = new Symbol();
        var bell = new Symbol();
        var plum = new Symbol();
        var watermelon = new Symbol ();
        var lemon  = new Symbol();
        var cherry = new Symbol();

        // set image path
        redseven.setImage("/assets/images/redseven.png");
        bell.setImage("/assets/images/bell.png");
        plum.setImage("/assets/images/plum.png");
        watermelon.setImage("/assets/images/watermelon.png");
        lemon.setImage("/assets/images/lemon.png");
        cherry.setImage("assets/images/cherry.png");

        // set image values
        redseven.setImageValue(7);
        bell.setImageValue(6)
        plum.setImageValue(4);
        watermelon.setImageValue(5);
        lemon.setImageValue(3);
        cherry.setImageValue(2);

        // image array
        List = [redseven,bell,plum,watermelon,lemon,cherry];

    }
}

// symbol class .. set and get the images and image values
class Symbol{
    imageValue : number;
    image :  string;

    constructor(){
        this.imageValue=0;  // initialize to 0
        this.image=""; // initialize to null
    }

    setImageValue(imageValue : number){ //set image values
        this.imageValue=imageValue;
    }

    getImageValue(){
        return this.imageValue; //get image values
    }

    setImage (location:string){ //set image location
        this.image=location;
    }

    getImage(){
        return this.image;  // get image location
    }

}


//addCoin
function addCoin(){
    coinValue++;
    document.getElementById("status").innerHTML = coinValue+" coin added"; // AddCoin status
    var button=<HTMLInputElement> document.getElementById("btnBetOne"); // betOne button enable
    button.disabled = false;
    if(coinValue>=3) {
        var button = <HTMLInputElement> document.getElementById("btnBetMax"); // betMax button enable
        button.disabled = false;
    }
    setAddCoinValue();
}

function setAddCoinValue(){
    (<HTMLInputElement>document.getElementById("txtAdd")).value = " " + coinValue; // set values to the addCoin text box
}

//BetOne Calculations
function BetOne(){

    if(coinValue>0){
        coinValue--;    // when betOne button click addCoin reduce from 1
        betValue++;    //until addCoin 0 bet area'll increase  by 1
        document.getElementById("status").innerHTML = 1+" bet is added and current bet value is " + betValue; // BetOne status
        var button=<HTMLInputElement> document.getElementById("btnSpin"); //spin button enable
        button.disabled = false;
    }else{
        alert("There's no enough  credit to bet. Please add a coin")   //coinValue less 0 show an alert msg
        document.getElementById("status").innerHTML = "There's no enough  credit to bet"; // BetOne error status
        var button=<HTMLInputElement> document.getElementById("btnBetOne"); // betOne button disable
        button.disabled = true;

        }
    setbetValue();
    setAddCoinValue();
    }

function setbetValue(){
    (<HTMLInputElement>document.getElementById("txtBet")).value = " " + betValue; // set values to the betCoin text box
}

//BetMax Calculations
function BetMax(){

    if(coinValue>2){
        coinValue = coinValue - 3;  // when click betMax addCoin'll reduce by 3
        betValue = betValue + 3;   //when click betMax betArea'll increase by 3
        document.getElementById("status").innerHTML="Max bet 3 is added and current bet value is " +betValue; // BetMax status
        var button=<HTMLInputElement> document.getElementById("btnSpin"); // spin button enable
        button.disabled = false;

    }else{
        alert("There's no enough  credit to bet")    //coinValue less or equal to 2  show an alert msg
        document.getElementById("status").innerHTML="There's no enough  credit to bet. Please add three coins or more" // BetMax error status
        var button=<HTMLInputElement> document.getElementById("btnBetMax"); // betMax button disable
        button.disabled = true;
    }
    setBetValue();
    setAddCoinValue();
}

function setBetValue(){
    (<HTMLInputElement>document.getElementById("txtBet")).value = " " + betValue; // set values to the betCoin text box
}

//Reset
function Reset(){
    coinValue = coinValue + betValue; // when reset bet values adding to the coin value
    betValue = 0; // bet value reset to 0

    setReset();
    setBetValue();
}

function setReset() {
       (<HTMLInputElement>document.getElementById("txtAdd")).value = " " + coinValue;
    document.getElementById("status").innerHTML="Reset the bet area and add all bet value's to the credit" // Reset status
}


//Spin
function Spin() {
  if(betValue==0){

      var button=<HTMLInputElement> document.getElementById("btnSpin"); // spin button disable
      button.disabled = true;

      alert("Bet a coin to proceed"); // can't spin alert
      document.getElementById("status").innerHTML = ("Bet a coin to proceed" )// spin status
  }
  else {

      var button=<HTMLInputElement> document.getElementById("btnSpin"); // spin button disable
      button.disabled = true;
      var button=<HTMLInputElement> document.getElementById("btnBetMax"); // betMax button disable
      button.disabled = true;
      var button=<HTMLInputElement> document.getElementById("btnBetOne"); // betOne button disable
      button.disabled = true;
      var button=<HTMLInputElement> document.getElementById("btnAdd"); // AddCoin button disable
      button.disabled = true;
      var button=<HTMLInputElement> document.getElementById("btnReset"); // reset button disable
      button.disabled = true;
      var button=<HTMLInputElement> document.getElementById("btnStatistics"); // statistics button disable
      button.disabled = true;
      document.getElementById("status").innerHTML = ("Spinning"); // spin status



      var images = new Images();

      if(spin1==true){
          reel1 = setInterval(function () {
              var random = Math.floor(Math.random() * List.length);
              (<HTMLImageElement>document.getElementById("reel1")).src = List[random].getImage();   //get the reel one image value
              (<HTMLImageElement>document.getElementById("reel1")).onclick= function(e) { //image onclick function
                  if (e.which == 1) { // when reel1 clicked this execute
                  clearInterval(reel1);   // reel1 setInteval will clear
                  score1 = List[random].getImageValue(); // get the reel1 value the the score1
                  spin1 = false; // spin will stoped
                  Calc(); // cal function will execute
              }
          }
          }, 120); // spinning time
      }

      if(spin2==true){
          reel2 = setInterval(function () {
              var random = Math.floor(Math.random() * List.length);
              (<HTMLImageElement>document.getElementById("reel2")).src = List[random].getImage();
              (<HTMLImageElement>document.getElementById("reel2")).onclick= function(e) {
                  if (e.which == 1) {
                      clearInterval(reel2);
                      score2 = List[random].getImageValue();
                      spin2 = false;
                      Calc();
                  }
              }
          }, 120);
      }


      if(spin3==true){
          reel3 = setInterval(function () {
              var random = Math.floor(Math.random() * List.length);
              (<HTMLImageElement>document.getElementById("reel3")).src = List[random].getImage();
              (<HTMLImageElement>document.getElementById("reel3")).onclick= function(e){
                  if(e.which==1){
                      clearInterval(reel3);
                      score3=List[random].getImageValue();
                      spin3=false;
                      Calc();
                  }
              }
          }, 120);
      }
  }

    totalBet+=betValue; // calculate the total bet
    noOfPlay++;     // no of play will increase by 1

}

//calculation function
function Calc() {

    if (spin1 == false && spin2 == false && spin3 == false) {
        spin1=true;
        spin2=true;
        spin3=true;

        if (score1 == score2) {
            coinValue+= score1 * betValue; // calculate the coin value
            noOfWins++; // increase the no fo wins
            totalCretitValues+=coinValue; // calculate thee
        }
        else if (score2 == score3) {
            coinValue+= score2 * betValue;
            noOfWins++;
            totalCretitValues+=coinValue;
        }
        else if (score1 == score3) {
            coinValue+= score3 * betValue;
            noOfWins++;
            totalCretitValues+=coinValue;
        }else{
            alert("You lose");
            noOfLoss++;

        }
        betValue=0;
        document.getElementById("status").innerHTML = "You have earned " + coinValue + "$"; // AddCoin status
            setAddCoinValue(); // set coinValue to the coin txt
            setbetValue();  // set betValue to the bet txt
    }

}

// reel1 stop function
function stopReel1(){
    setBetValue(); // set betValue to the bet txt
    clearInterval(reel1); // clearIntavale reel1
    document.getElementById("status").innerHTML=("Reel 1 Stop") // Statistics status
    buttonEnable();// all buttons will enabled

}

// reel2 stop function
function stopReel2(){
    setBetValue();  // set betValue to the bet txt
    clearInterval(reel2);   // clearIntavale reel2
    document.getElementById("status").innerHTML=("Reel 2 Stop") // Statistics status
    buttonEnable();
}

// reel3 stop function
function stopReel3(){
    setBetValue();  // set betValue to the bet txt
    clearInterval(reel3);   // clearIntavale reel3
    document.getElementById("status").innerHTML=("Reel 3 Stop") // Statistics status
    buttonEnable();
}


var sessionSorageValues
//Statistics
function Statistics(){                                                                       // pass value to the statistics
    sessionSorageValues={"Total Credits": totalCretitValues, "Total bets":  totalBet,"Total Play": noOfPlay,"Total Wins": noOfWins,"Total Loss": noOfLoss};
    sessionStorage.setItem('listOfValues',JSON.stringify(sessionSorageValues));
    window.open("Statistics"); // new window
    document.getElementById("status").innerHTML="Statistics" // Statistics status

}

function buttonEnable(){
    var button=<HTMLInputElement> document.getElementById("btnBetMax"); // betMax button disable
    button.disabled = false;
    var button=<HTMLInputElement> document.getElementById("btnBetOne"); // betOne button disable
    button.disabled = false;
    var button=<HTMLInputElement> document.getElementById("btnAdd"); // aaCoin button disable
    button.disabled = false;
    var button=<HTMLInputElement> document.getElementById("btnReset"); // reset button disable
    button.disabled = false;
    var button=<HTMLInputElement> document.getElementById("btnStatistics"); // statistics button disable
    button.disabled = false;
}


